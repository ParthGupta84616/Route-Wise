import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import MapView, { Polyline, Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { ChargingStationMarker } from '@/components/ChargingStationMarker';
import { RoutePlanResponse } from '@/types';
import { ArrowLeft, Navigation, Clock, Battery } from 'lucide-react-native';

export default function MapViewScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ routeData: string; source: string; destination: string }>();

  const [routeData, setRouteData] = useState<RoutePlanResponse | null>(null);
  const [region, setRegion] = useState<any>(null);

  useEffect(() => {
    if (params.routeData) {
      try {
        const data = JSON.parse(params.routeData);
        setRouteData(data);

        if (data.routeCoordinates && data.routeCoordinates.length > 0) {
          const lats = data.routeCoordinates.map((coord: [number, number]) => coord[0]);
          const lngs = data.routeCoordinates.map((coord: [number, number]) => coord[1]);

          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);

          setRegion({
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: (maxLat - minLat) * 1.3,
            longitudeDelta: (maxLng - minLng) * 1.3,
          });
        }
      } catch (error) {
        console.error('Failed to parse route data:', error);
      }
    }
  }, [params.routeData]);

  if (!routeData || !region) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading map...</Text>
      </View>
    );
  }

  const coordinates = routeData.routeCoordinates.map(coord => ({
    latitude: coord[0],
    longitude: coord[1],
  }));

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color="#1e293b" />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>{params.destination}</Text>
          <Text style={styles.headerSubtitle}>
            {(routeData.totalDistance / 1000).toFixed(1)} km
          </Text>
        </View>
      </View>

      <MapView
        style={styles.map}
        initialRegion={region}
        provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
      >
        <Polyline
          coordinates={coordinates}
          strokeColor="#2563eb"
          strokeWidth={4}
        />

        {coordinates.length > 0 && (
          <>
            <Marker
              coordinate={coordinates[0]}
              pinColor="#10b981"
              title="Start"
              description={params.source}
            />
            <Marker
              coordinate={coordinates[coordinates.length - 1]}
              pinColor="#ef4444"
              title="Destination"
              description={params.destination}
            />
          </>
        )}

        {routeData.chargingStations.map((station, index) => (
          <ChargingStationMarker key={`${station.id}-${index}`} station={station} />
        ))}
      </MapView>

      <View style={styles.infoCard}>
        <View style={styles.infoItem}>
          <Clock size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>ETA</Text>
            <Text style={styles.infoValue}>{routeData.eta || 'N/A'}</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.infoItem}>
          <Navigation size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>Distance</Text>
            <Text style={styles.infoValue}>
              {(routeData.totalDistance / 1000).toFixed(1)} km
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.infoItem}>
          <Battery size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>Battery Usage</Text>
            <Text style={styles.infoValue}>{routeData.batteryUsage.toFixed(1)}%</Text>
          </View>
        </View>
      </View>

      {routeData.chargingStations.length > 0 && (
        <View style={styles.stationsCard}>
          <Text style={styles.stationsTitle}>
            {routeData.chargingStations.length} Charging Stop{routeData.chargingStations.length !== 1 ? 's' : ''}
          </Text>
          <Text style={styles.stationsText}>
            Tap markers on the map to see details
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#fff',
    zIndex: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    padding: 4,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
  map: {
    flex: 1,
  },
  infoCard: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-around',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  divider: {
    width: 1,
    backgroundColor: '#e2e8f0',
  },
  stationsCard: {
    position: 'absolute',
    top: 140,
    left: 20,
    right: 20,
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 12,
  },
  stationsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  stationsText: {
    fontSize: 12,
    color: '#dcfce7',
  },
});
