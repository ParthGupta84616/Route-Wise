import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useVehicles } from '@/hooks/useVehicles';
import { ArrowLeft } from 'lucide-react-native';

export default function EditVehicleScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { vehicles, updateVehicle, isUpdating } = useVehicles();

  const [name, setName] = useState('');
  const [model, setModel] = useState('');
  const [size, setSize] = useState('');
  const [batteryCapacity, setBatteryCapacity] = useState('');
  const [consumptionRate, setConsumptionRate] = useState('');
  const [kmRun, setKmRun] = useState('');
  const [degradation, setDegradation] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const vehicle = vehicles.find(v => v.id === id);
    if (vehicle) {
      setName(vehicle.name);
      setModel(vehicle.model);
      setSize(vehicle.size);
      setBatteryCapacity(vehicle.batteryCapacity.toString());
      setConsumptionRate(vehicle.consumptionRate.toString());
      setKmRun(vehicle.kmRun.toString());
      setDegradation(vehicle.degradation?.toString() || '');
    }
  }, [id, vehicles]);

  const handleSubmit = async () => {
    setError('');

    if (!name || !model || !size || !batteryCapacity || !consumptionRate || !kmRun) {
      setError('Please fill in all required fields');
      return;
    }

    const batteryNum = parseFloat(batteryCapacity);
    const consumptionNum = parseFloat(consumptionRate);
    const kmNum = parseFloat(kmRun);
    const degradationNum = degradation ? parseFloat(degradation) : undefined;

    if (isNaN(batteryNum) || isNaN(consumptionNum) || isNaN(kmNum)) {
      setError('Please enter valid numbers');
      return;
    }

    try {
      await updateVehicle({
        id,
        vehicle: {
          name,
          model,
          size,
          batteryCapacity: batteryNum,
          consumptionRate: consumptionNum,
          kmRun: kmNum,
          degradation: degradationNum,
        },
      });
      router.back();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update vehicle');
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color="#1e293b" />
        </TouchableOpacity>
        <Text style={styles.title}>Edit Vehicle</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
        <View style={styles.inputContainer}>
          <Text style={styles.label}>Vehicle Name *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., My Tesla"
            value={name}
            onChangeText={setName}
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Model *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., Model 3"
            value={model}
            onChangeText={setModel}
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Size *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., Sedan"
            value={size}
            onChangeText={setSize}
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Battery Capacity (kWh) *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., 75"
            value={batteryCapacity}
            onChangeText={setBatteryCapacity}
            keyboardType="decimal-pad"
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Consumption Rate (kWh/100km) *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., 15.5"
            value={consumptionRate}
            onChangeText={setConsumptionRate}
            keyboardType="decimal-pad"
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Distance Run (km) *</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., 5000"
            value={kmRun}
            onChangeText={setKmRun}
            keyboardType="decimal-pad"
            editable={!isUpdating}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Battery Degradation (%)</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g., 5"
            value={degradation}
            onChangeText={setDegradation}
            keyboardType="decimal-pad"
            editable={!isUpdating}
          />
        </View>

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <TouchableOpacity
          style={[styles.button, isUpdating && styles.buttonDisabled]}
          onPress={handleSubmit}
          disabled={isUpdating}
        >
          {isUpdating ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>Save Changes</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    padding: 4,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#334155',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#1e293b',
  },
  button: {
    backgroundColor: '#2563eb',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  error: {
    color: '#ef4444',
    fontSize: 14,
    marginBottom: 12,
    textAlign: 'center',
  },
});
