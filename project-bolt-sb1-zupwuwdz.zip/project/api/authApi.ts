import { axiosClient } from './axiosClient';
import { AuthResponse, LoginCredentials, RegisterCredentials, User } from '@/types';
import { storage } from '@/utils/storage';

export const authApi = {
  async register(credentials: RegisterCredentials): Promise<AuthResponse> {
    const response = await axiosClient.post<AuthResponse>('/auth/register', credentials);
    if (response.data.token) {
      await storage.saveToken(response.data.token);
    }
    return response.data;
  },

  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    const response = await axiosClient.post<AuthResponse>('/auth/login', credentials);
    if (response.data.token) {
      await storage.saveToken(response.data.token);
    }
    return response.data;
  },

  async getCurrentUser(): Promise<User> {
    const response = await axiosClient.get<User>('/auth/me');
    return response.data;
  },

  async logout(): Promise<void> {
    await storage.removeToken();
    await storage.removeActiveVehicle();
  },
};
