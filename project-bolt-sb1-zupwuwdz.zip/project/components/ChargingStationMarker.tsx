import { View, Text, StyleSheet } from 'react-native';
import { Marker, Callout } from 'react-native-maps';
import { ChargingStation } from '@/types';
import { Zap, Clock, Navigation2 } from 'lucide-react-native';

interface ChargingStationMarkerProps {
  station: ChargingStation;
}

export function ChargingStationMarker({ station }: ChargingStationMarkerProps) {
  return (
    <Marker
      coordinate={{
        latitude: station.lat,
        longitude: station.lng,
      }}
      pinColor="#10b981"
      title={station.name}
    >
      <View style={styles.markerContainer}>
        <View style={styles.marker}>
          <Zap size={16} color="#fff" />
        </View>
      </View>
      <Callout tooltip>
        <View style={styles.callout}>
          <Text style={styles.calloutTitle}>{station.name}</Text>

          <View style={styles.calloutRow}>
            <Zap size={14} color="#2563eb" />
            <Text style={styles.calloutText}>{station.chargingSpeedKw} kW</Text>
          </View>

          <View style={styles.calloutRow}>
            <Clock size={14} color="#2563eb" />
            <Text style={styles.calloutText}>
              {Math.round(station.estimatedChargingTime)} min charging
            </Text>
          </View>

          <View style={styles.calloutRow}>
            <Navigation2 size={14} color="#2563eb" />
            <Text style={styles.calloutText}>
              ETA: {Math.round(station.etaFromPrevious)} min
            </Text>
          </View>

          {station.amenities.length > 0 && (
            <View style={styles.amenities}>
              {station.amenities.map((amenity, index) => (
                <View key={index} style={styles.amenityTag}>
                  <Text style={styles.amenityTagText}>{amenity}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
      </Callout>
    </Marker>
  );
}

const styles = StyleSheet.create({
  markerContainer: {
    alignItems: 'center',
  },
  marker: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10b981',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  callout: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    minWidth: 200,
    maxWidth: 250,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  calloutTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 8,
  },
  calloutRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  calloutText: {
    fontSize: 14,
    color: '#64748b',
  },
  amenities: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    marginTop: 8,
  },
  amenityTag: {
    backgroundColor: '#eff6ff',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  amenityTagText: {
    fontSize: 11,
    color: '#2563eb',
    fontWeight: '500',
  },
});
