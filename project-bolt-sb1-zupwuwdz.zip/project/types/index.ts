export interface User {
  id: string;
  email: string;
  name?: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  email: string;
  password: string;
  name?: string;
}

export interface Vehicle {
  id: string;
  userId: string;
  name: string;
  model: string;
  size: string;
  batteryCapacity: number;
  consumptionRate: number;
  kmRun: number;
  degradation?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface VehicleInput {
  name: string;
  model: string;
  size: string;
  batteryCapacity: number;
  consumptionRate: number;
  kmRun: number;
  degradation?: number;
}

export interface GeocodeResult {
  lat: number;
  lng: number;
  formattedAddress: string;
}

export interface ChargingStation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  amenities: string[];
  chargingSpeedKw: number;
  etaFromPrevious: number;
  estimatedChargingTime: number;
  distanceFromPrevious: number;
}

export interface RouteSegment {
  coordinates: [number, number][];
  weather?: string;
  traffic?: string;
}

export interface RoutePlanRequest {
  source: string;
  destination: string;
  vehicleId: string;
  currentChargePercent: number;
  segmentDistanceMeters?: number;
  preferredMaxDetourKm?: number;
  amenitiesFilter?: string[];
  preferredChargingSpeedKw?: number;
}

export interface RoutePlanResponse {
  routeCoordinates: [number, number][];
  chargingStations: ChargingStation[];
  totalDistance: number;
  totalTime: number;
  batteryUsage: number;
  eta: string;
  segments?: RouteSegment[];
}
