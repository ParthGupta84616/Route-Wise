import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const TOKEN_KEY = 'auth_token';
const ACTIVE_VEHICLE_KEY = 'active_vehicle';

export const storage = {
  async saveToken(token: string): Promise<void> {
    if (Platform.OS === 'web') {
      await AsyncStorage.setItem(TOKEN_KEY, token);
    } else {
      await SecureStore.setItemAsync(TOKEN_KEY, token);
    }
  },

  async getToken(): Promise<string | null> {
    if (Platform.OS === 'web') {
      return await AsyncStorage.getItem(TOKEN_KEY);
    } else {
      return await SecureStore.getItemAsync(TOKEN_KEY);
    }
  },

  async removeToken(): Promise<void> {
    if (Platform.OS === 'web') {
      await AsyncStorage.removeItem(TOKEN_KEY);
    } else {
      await SecureStore.deleteItemAsync(TOKEN_KEY);
    }
  },

  async saveActiveVehicle(vehicleId: string): Promise<void> {
    await AsyncStorage.setItem(ACTIVE_VEHICLE_KEY, vehicleId);
  },

  async getActiveVehicle(): Promise<string | null> {
    return await AsyncStorage.getItem(ACTIVE_VEHICLE_KEY);
  },

  async removeActiveVehicle(): Promise<void> {
    await AsyncStorage.removeItem(ACTIVE_VEHICLE_KEY);
  },
};
