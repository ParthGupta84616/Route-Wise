import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useState, useEffect } from 'react';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { WebView } from 'react-native-webview';
import { RoutePlanResponse } from '@/types';
import { ArrowLeft, Navigation, Clock, Battery } from 'lucide-react-native';

export default function MapViewScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ routeData: string; source: string; destination: string }>();

  const [routeData, setRouteData] = useState<RoutePlanResponse | null>(null);
  const [mapHtml, setMapHtml] = useState<string>('');

  useEffect(() => {
    if (params.routeData) {
      try {
        const data = JSON.parse(params.routeData);
        setRouteData(data);
        generateMapHtml(data);
      } catch (error) {
        console.error('Failed to parse route data:', error);
      }
    }
  }, [params.routeData]);

  const generateMapHtml = (data: RoutePlanResponse) => {
    const coordinates = data.routeCoordinates || [];
    if (coordinates.length === 0) return;

    const centerLat = coordinates[Math.floor(coordinates.length / 2)][0];
    const centerLng = coordinates[Math.floor(coordinates.length / 2)][1];

    const routePoints = coordinates.map(coord => `[${coord[0]}, ${coord[1]}]`).join(',');
    
    const chargingStations = data.chargingStations.map(station => 
      `L.marker([${station.lat}, ${station.lng}])
        .addTo(map)
        .bindPopup(\`
          <div style="font-family: sans-serif;">
            <h3 style="margin: 0 0 8px 0; color: #2563eb;">${station.name}</h3>
            <p style="margin: 4px 0;"><strong>⚡ ${station.chargingSpeedKw} kW</strong></p>
            <p style="margin: 4px 0;">🕐 ${Math.round(station.estimatedChargingTime)} min charging</p>
            <p style="margin: 4px 0;">🚗 ETA: ${Math.round(station.etaFromPrevious)} min</p>
            ${station.amenities.length > 0 ? `<p style="margin: 4px 0;">🏪 ${station.amenities.join(', ')}</p>` : ''}
          </div>
        \`);`
    ).join('\n');

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
          body { margin: 0; padding: 0; }
          #map { height: 100vh; width: 100vw; }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script>
          // Initialize map
          var map = L.map('map').setView([${centerLat}, ${centerLng}], 10);
          
          // Add OpenStreetMap tiles
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 18,
          }).addTo(map);

          // Add route polyline
          var routeCoords = [${routePoints}];
          if (routeCoords.length > 0) {
            L.polyline(routeCoords, {
              color: '#2563eb',
              weight: 4,
              opacity: 0.8
            }).addTo(map);

            // Add start marker
            L.marker(routeCoords[0])
              .addTo(map)
              .bindPopup('<div style="font-family: sans-serif;"><h3 style="color: #10b981;">🏁 Start</h3><p>${params.source}</p></div>');

            // Add end marker
            L.marker(routeCoords[routeCoords.length - 1])
              .addTo(map)
              .bindPopup('<div style="font-family: sans-serif;"><h3 style="color: #ef4444;">🎯 Destination</h3><p>${params.destination}</p></div>');

            // Fit map to route bounds
            var group = new L.featureGroup([L.polyline(routeCoords)]);
            map.fitBounds(group.getBounds().pad(0.1));
          }

          // Add charging stations
          ${chargingStations}
        </script>
      </body>
      </html>
    `;

    setMapHtml(html);
  };

  if (!routeData || !mapHtml) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading map...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color="#1e293b" />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>{params.destination}</Text>
          <Text style={styles.headerSubtitle}>
            {(routeData.totalDistance / 1000).toFixed(1)} km
          </Text>
        </View>
      </View>

      <WebView
        style={styles.map}
        source={{ html: mapHtml }}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        scalesPageToFit={true}
      />

      <View style={styles.infoCard}>
        <View style={styles.infoItem}>
          <Clock size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>ETA</Text>
            <Text style={styles.infoValue}>{routeData.eta || 'N/A'}</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.infoItem}>
          <Navigation size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>Distance</Text>
            <Text style={styles.infoValue}>
              {(routeData.totalDistance / 1000).toFixed(1)} km
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.infoItem}>
          <Battery size={20} color="#2563eb" />
          <View>
            <Text style={styles.infoLabel}>Battery Usage</Text>
            <Text style={styles.infoValue}>{routeData.batteryUsage.toFixed(1)}%</Text>
          </View>
        </View>
      </View>

      {routeData.chargingStations.length > 0 && (
        <View style={styles.stationsCard}>
          <Text style={styles.stationsTitle}>
            {routeData.chargingStations.length} Charging Stop{routeData.chargingStations.length !== 1 ? 's' : ''}
          </Text>
          <Text style={styles.stationsText}>
            Tap markers on the map for details
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#fff',
    zIndex: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  backButton: {
    padding: 4,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#64748b',
    marginTop: 2,
  },
  map: {
    flex: 1,
  },
  infoCard: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-around',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoLabel: {
    fontSize: 12,
    color: '#64748b',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
  },
  divider: {
    width: 1,
    backgroundColor: '#e2e8f0',
  },
  stationsCard: {
    position: 'absolute',
    top: 140,
    left: 20,
    right: 20,
    backgroundColor: '#10b981',
    borderRadius: 12,
    padding: 12,
  },
  stationsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  stationsText: {
    fontSize: 12,
    color: '#dcfce7',
  },
});
