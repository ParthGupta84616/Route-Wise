import axios from 'axios';
import { storage } from '@/utils/storage';

const API_BASE_URL = 'https://route-wise.onrender.com/api';

export const axiosClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

axiosClient.interceptors.request.use(
  async (config) => {
    const token = await storage.getToken();
    console.log('Token from storage:', token);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axiosClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await storage.removeToken();
      await storage.removeActiveVehicle();
    }
    return Promise.reject(error);
  }
);
