import { axiosClient } from './axiosClient';
import { Vehicle, VehicleInput } from '@/types';

export const vehicleApi = {
  async getVehicles(): Promise<Vehicle[]> {
    console.log('Fetching vehicles from API');
    const response = await axiosClient.get<Vehicle[]>('/vehicles');
    console.log('Vehicles fetched successfully:', response.data);
    return response.data;
  },

  async createVehicle(vehicle: VehicleInput): Promise<Vehicle> {
    const response = await axiosClient.post<Vehicle>('/vehicles', vehicle);
    return response.data;
  },

  async updateVehicle(id: string, vehicle: Partial<VehicleInput>): Promise<Vehicle> {
    const response = await axiosClient.put<Vehicle>(`/vehicles/${id}`, vehicle);
    return response.data;
  },

  async deleteVehicle(id: string): Promise<void> {
    await axiosClient.delete(`/vehicles/${id}`);
  },
};
