# EV Route Planner - System Diagrams

This folder contains all system architecture and flow diagrams in Mermaid format.

## Files

1. **01-system-architecture.mmd** - Overall system architecture
2. **02-authentication-flow.mmd** - User authentication sequence
3. **03-vehicle-management-flow.mmd** - Vehicle CRUD operations
4. **04-route-planning-flow.mmd** - Complete route planning sequence
5. **05-map-visualization-flow.mmd** - Map rendering and interaction
6. **06-backend-algorithm.mmd** - Route calculation algorithm
7. **07-user-journey.mmd** - End-to-end user journey
8. **08-data-flow-architecture.mmd** - Data flow between layers

## How to View

### VS Code
Install the **Mermaid Preview** extension and open any `.mmd` file.

### Online
Copy the content and paste into [Mermaid Live Editor](https://mermaid.live/)

### Command Line
```bash
npm install -g @mermaid-js/mermaid-cli
mmdc -i 01-system-architecture.mmd -o output.png
```

## Key Press-to-Action Flows

- **Login Button** → JWT Token → Dashboard
- **Add Vehicle Button** → Form → MongoDB Save → Vehicle List
- **Plan Route Button** → Geocode → Route Calculation → Map View
- **View on Map** → WebView → Leaflet Rendering → Interactive Map
- **Station Marker Click** → Popup → Charging Details
